# Nabilly's FX News
Live Forex Factory-style app with notifications and sentiment analysis.