import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>📈 Nabilly's FX News</h1>
      <p>This is a live forex sentiment and news dashboard. (Live version coming soon!)</p>
    </div>
  );
}